
CREATE DATABASE library_db;


CREATE TABLE books(
    book_id SERIAL PRIMARY KEY,
    title VARCHAR(100),
    author VARCHAR(100),
    year_published INT,
    isAvailable BOOLEAN,
    price NUMERIC(8,2),
    publication VARCHAR(100)
);


INSERT INTO books(title, author, year_published, isAvailable, price, publication)
VALUES 
('The Hidden Life', 'Nora Lane', 2005, TRUE, 510.00, 'Pearson'),
('Digital Fortress', 'Dan Brown', 1998, FALSE, 480.00, 'Random House'),
('The Innovators', 'Walter Isaacson', 2014, TRUE, 610.00, 'Simon & Schuster'),
('Educating Minds', 'Lana Morris', 2007, TRUE, 350.00, 'HarperCollins'),
('Lost Horizons', 'James Hilton', 1933, FALSE, 275.00, 'Macmillan'),
('Tomorrow’s World', 'Emily Stone', 2021, TRUE, 720.00, 'XYZ'),
('The Code Breaker', 'Walter Isaacson', 2020, TRUE, 690.00, 'ABC Publishers'),
('Invisible Women', 'Caroline Criado Perez', 2019, FALSE, 599.00, 'XYZ'),
('Factfulness', 'Hans Rosling', 2018, TRUE, 400.00, 'Flatiron Books'),
('The Motivation Myth', 'Jeff Haden', 2017, TRUE, 299.00, 'Penguin'),
('Outliers', 'Malcolm Gladwell', 2008, FALSE, 375.00, 'Little, Brown'),
('Deep Medicine', 'Eric Topol', 2019, TRUE, 650.00, 'XYZ'),
('Designing Your Life', 'Bill Burnett', 2016, TRUE, 540.00, 'Knopf'),
('The Power of Habit', 'Charles Duhigg', 2012, FALSE, 430.00, 'XYZ'),
('Rebooting AI', 'Gary Marcus', 2019, TRUE, 300.00, 'Pantheon');


select * from books where year_published > 2000;

select * from books where price < 599.00 order by price desc;

select * from books order by price desc limit 3;

select * from books order by year_published desc offset 2 limit 2;

select * from books where publication = 'XYZ' order by title;